import React from 'react';

const Counter = function(props){
	return (
        <div>{props.counter}</div>
    )
}

export default Counter;